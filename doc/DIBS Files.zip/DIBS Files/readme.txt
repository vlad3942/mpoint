Please upload all files through DIBS' Admin under "Custom Pages" / "Egne Sider".
The files are used to render the DIBS Custom Payment Pages.
If a custom Stylesheet is used, changes should be made to the styles part of the HTML files:
- payment.html
- accept.html
- decline.html