<?php
	require_once('class.pgwapi.php');

	/*
	 * return codes
	 * 
	 * 0 = Approved
	 * 1 = Failed
	 * 2 = On ore more jobs in queue for this transaction
	 * 3 = No transaction found with that transactnum
	 * 4 = Amount is bigger then original amount
	 * 5 = Authorized
	 * 6 = Captured
	 * 7 = canceled
	 * 8 = Refounded
	 * 9 = Subscription
	 * 10 = orderid is missing
	 * 11 = bankMerchantID is missing
	 * 12 = boNO is missing
	 * 13 = missing transactnum
	 * 14 = missing amount
	 * 15 = not a valid amount
	 * 16 = not a valid orderid
	 * 17 = not a valid orderidprefix
	 * 18 = not a valid trasactnum
	 * 19 = Subscriber transaction not found
	 * 20 = missing orderid
	 */
	
	$pgwApi = new Pgwapi();
	
	$pgwApi->pgwUsername = 'username';
	$pgwApi->pgwPassword = 'password';
	
	$pgwApi->transactnum = '1111';
	
	try {
		$result = $pgwApi->captureTransaction();
	} catch ( Exception $e ) {
		
		echo 'Error from API connection:'."<BR>\n";
		echo '-> '.$e->getMessage() ."<BR>\n";
		echo "<BR>\n";		
		echo 'Debug From API connection: '."<BR><BR>\n";
		
		echo 'API Request'."<BR><BR>\n";
		echo '<pre>';
		echo $pgwApi->showRequest();
		echo '</pre>';
		echo 'API Response'."<BR><BR>\n";
		echo '<pre>';
		echo $pgwApi->showResponse();
		echo '</pre>';
		echo 'API Debug'."<BR><BR>\n";
		echo '<pre>';
		echo $pgwApi->showDebug();
		echo '</pre>';
		echo '</pre>';
	}
	echo 'API result: '. $result;
	
?>