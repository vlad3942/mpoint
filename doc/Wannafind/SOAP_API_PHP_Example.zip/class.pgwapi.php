<?php
	require_once('lib/nusoap.php');
	
	class Pgwapi {
		
		public $pgwUsername;
		public $pgwPassword;
		
		private $debug = false;
		
		public $transactnum;
		public $orderid;
		public $amount;
		public $bankMerchantID;
		public $boNo;
		public $type;
		
		public function connect() {
			if( !(string)$this->pgwUsername || !(string)$this->pgwPassword ) {
				throw new Exception('Username or password is not set');
			}
			
			$this->apiConn = new nusoap_client('https://betaling.wannafind.dk/api/customerAPI.php?wsdl', true);
			$this->apiConn->setCredentials((string)$this->pgwUsername,(string)$this->pgwPassword);
		}
		
		/*
		 * Capture Transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function captureTransaction() {
			$this->connect();
			
			$result = $this->apiConn->call('captureTransaction', array('transactnum' => (int)$this->transactnum));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Cancel Transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function cancelTransaction() {
			$this->connect();
			
			$result = $this->apiConn->call('cancelTransaction', array('transactnum' => (int)$this->transactnum));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Cancel Transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function releaseSubscription() {
			$this->connect();
			
			$result = $this->apiConn->call('releaseSubscription', array('transactnum' => (int)$this->transactnum));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Change Amount
		 * @parm
		 * @return boolean
		 *
         */
		public function changeAmount() {
			$this->connect();
			
			$result = $this->apiConn->call('changeAmount', array('transactnum' => (int)$this->transactnum, 'amount' => (int)$this->amount));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Check Transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function checkTransaction() {
			$this->connect();
			
			$result = $this->apiConn->call('checkTransaction', array('transactnum' => (int)$this->transactnum,
	    						  									 'type' => (string)$this->type,
	    						  									 'orderid' => (string)$this->orderid,
	    						  									 'bankMerchantID' => (string)$this->bankMerchantID,
	    						  									 'boNo' => (string)$this->boNo));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Renew transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function renewTransaction() {
			$this->connect();
			
			$result = $this->apiConn->call('renewTransaction', array('transactnum' =>(int)$this->transactnum));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Subscribe authentication
		 * @parm
		 * @return boolean
		 *
         */
		public function authSubscribe() {
			$this->connect();
			
			$result = $this->apiConn->call('authSubscribe', array('transactnum' => (int)$this->transactnum,
	    						  								  'amount' => (int)$this->amount,
	    						  								  'orderid' => (string)$this->orderid,
	    						  								  'orderidprefix' => (string)$this->orderidprefix));
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}
		
		/*
		 * Credit transaction
		 * @parm
		 * @return boolean
		 *
         */
		public function creditTransaction() {
			$this->connect();
			
			$result = $this->apiConn->call('creditTransaction', array('transactnum' => (int)$this->transactnum,
	    						  								  'amount' => (int)$this->amount));
			
			
			if ($this->apiConn->fault) {
    			throw new Exception('Connection error with the paymentgateway api');
			} else {
    			$err = $this->apiConn->getError();
    			if ($err) {
        			throw new Exception($err);
    			} else {
        			return $result;
    			}
			}
		}

		public function showRequest() {
			return htmlspecialchars($this->apiConn->request, ENT_QUOTES);
		}
		
		public function showResponse() {
			return htmlspecialchars($this->apiConn->response, ENT_QUOTES);
		}
		
		public function showDebug() {
			return htmlspecialchars($this->apiConn->debug_str, ENT_QUOTES);
		}
	}

?>