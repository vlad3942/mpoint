<?php

require 'init.php';
require 'header.php';

var_dump(
    $pg->getMethods()
);

require 'footer.php';

?>