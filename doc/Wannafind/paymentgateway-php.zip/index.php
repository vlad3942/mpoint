<?php

require 'init.php';


/** ADD PHP SESSION ID - THIS WILL BE ADDED TO QUERYSTRING ON ACCEPT/DECLINE PAGE **/
$pg->addTransferredVariable('PHPSESSID', session_id());


/** SET PURCHASE INFO IN A SESSION VARIABLE **/
$payment = array(
    'amount' => 1000,
    'orderid' => 1,
    'currency' => 208
);
session_register('payment');



require 'header.php';

?>
<div id="paymentBox">
    <h1>Online betaling</h1>
    <p>V�lg venligst hvilken betalingsl�sning du �nsker at benytte:</p>
    <ul>
        <li><a href="<?php echo HTTPS_LOCATION; ?>payment_form.php?PHPSESSID=<?php echo session_id(); ?>">SecureProxy</a></li>
        <li><a href="payment_window.php">Betalingsvindue</a></li>
    </ul>
    <p style="font-style: italic;margin-top:30px;">
        Husk at konfigurere applikationen med dit brugernavn, adgangskode, shopid, dom�nenavn og sti til applikationen i filen init.php linie 4 - 8.<br/>
        <br/>
        Bel�b, valuta og ordrenummer defineres som sessions variable i filen index.php linie 12 - 14.
    </p>
</div>
<?php require 'footer.php'; ?>