<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<meta http-equiv="content-language" content="en">
<title>Payment form example</title>
<style type="text/css">
body {
    font-family: verdana, helvetica, arial, sans-serif;
    background-color: rgb(245, 245, 245);
}
body, p, td, h1 {
    font-size: 11px;
    line-height: 15px;
}
.cardnum {
    width: 150px;
}
.emonth {
    
}
.eyear {
    
}
.cvc {
    width: 35px;
}
.cardnum, .emonth, .eyear, .cvc {
    border: 1px solid rgb(0, 0, 0);
    background-color: rgb(250, 250, 250);
}
div#paymentBox {
    width: 350px;
    border: 1px solid rgb(0, 0, 0);
    background-color: rgb(240, 250, 255);
    margin: 200px auto 20px auto;
    padding: 5px 20px;
}
h1 {
    font-size: 18px;
    line-height: 22px;
}
li {
    margin: 5px 0;
}
a {
    color: rgb(100, 100, 100);
    font-weight: bold;
}
</style>
</head>
<body>