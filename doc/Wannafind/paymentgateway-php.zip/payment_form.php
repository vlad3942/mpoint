<?php

require 'init.php';
require 'header.php';

?>

<div id="paymentBox">
    <h1>Betaling med kreditkort</h1>
    <?php echo $pg->parsePaymentForm('%%%FORMSTART%%%
    %%%SHOPID%%%
    %%%AMOUNT%%%

    %%%ORDERID%%%
        
    %%%CURRENCY%%%
    %%%PAYTYPE%%%
    %%%ACCEPTURL%%%
    %%%DECLINEURL%%%
    <table cellpadding="3" cellspacing="0" border="0" width="100%">
        <tr>
            <td><strong>Ordre nr.</strong></td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>' . $pg->orderid . '</td>
        </tr>
        <tr>
            <td><strong>Bel&oslash;b</strong></td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>DKK ' . number_format($pg->amount, 2, ',', '.') . '</td>
        </tr>
        <tr>
            <td><strong>Kortnummer</strong></td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>%%%CARDNUM%%%</td>
        </tr>
        <tr>
            <td><strong>Udl&oslash;bsdato</strong></td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>%%%EXPMONTH%%% / %%%EXPYEAR%%%</td>
        </tr>
        <tr>
            <td><strong>Kortnummer</strong></td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>%%%CVC%%%</td>
        </tr>
        <tr>
            <td colspan="3" align="center">%%%FORMSUBMIT%%%</td>
        </tr>
    </table>

    %%%FORMEND%%%'); ?>
</div>
    
<div align="center">
    <strong>Testkort oplysninger:</strong><br/>
    <table>
        <tr>
            <td>Kortnr.</td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>5019954345597256</td>
        </tr>
        <tr>
            <td>Udl�bsdato</td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>05/08</td>
        </tr>
        <tr>
            <td>Kontrolcifre</td>
            <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
            <td>605</td>
        </tr>
    </table>
</div>

<?php require 'footer.php'; ?>