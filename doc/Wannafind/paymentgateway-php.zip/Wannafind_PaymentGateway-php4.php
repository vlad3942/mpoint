<?php

/**
* PHP4 version of Wannafind_PaymentGateway
* You should use PHP5 version if PHP5 is available on your server
* @author       Zitcom.dk A/S - S�ren M�ller Hansen <smh@wannafind.dk>
* @version      $id$
* @example      For use cases, see init.php, payment_form.php, payment_window.php and payment_return.php
*/
class Wannafind_PaymentGateway
{
    var $methods = array();
    var $transferredVariables = array();
    
    var $shopid = '';
    var $username = '';
    var $password = '';
    var $amount = '';
    var $uniqueorderid = '';
    var $orderidprefix = '';
    var $orderid = '';
    var $currency = '';
    var $paytype = 'creditcard';
    var $authtype = '';
    var $checkmd5 = '';
    var $accepturl = '';
    var $declineurl = '';
    var $statusurl = '';
    var $callbackurl = '';
    var $cardtype = '';
    var $button_caption = '';
    var $lang = 'en';
    var $securitytext = false;
    
    function Wannafind_PaymentGateway()
    {
        $this->_addApiMethod(
            'apiCheckTransaction', 
            'pg.api.checktransack.php',
            array(
                'transacknum' => array('required' => true),
                'shopid' => array('required' => true)
            ),
            false
        );
        $this->_addApiMethod(
            'apiCancelTransaction', 
            'pg.api.canceltransack.php',
            array(
                'transacknum' => array('required' => true),
                'shopid' => array('required' => true)
            ),
            true
        );
        $this->_addApiMethod(
            'apiCaptureTransaction', 
            'pg.api.capturetransack.php',
            array(
                'transacknum' => array('required' => true),
                'shopid' => array('required' => true)
            ),
            true
        );
        $this->_addApiMethod(
            'apiChangeAmount', 
            'pg.api.changeamount.php',
            array(
                'transacknum' => array('required' => true),
                'shopid' => array('required' => true),
                'amount' => array('required' => true)
            ),
            true
        );
        $this->_addApiMethod(
            'apiRenewTransaction', 
            'pg.api.renewtransack.php',
            array(
                'transacknum' => array('required' => true),
                'shopid' => array('required' => true)
            ),
            true
        );
    }
    
    function getMethods()
    {
        $methods = $this->methods;
        foreach($methods as $method => $data)
        {
            unset( $data['remoteMethod'] );
            foreach( $data['arguments'] as $argument => $argdata )
            {
                if( isset( $this->$argument ) ) unset( $methods[$method]['arguments'][$argument] );
            }
        }
        return $methods;
    }
    
    function parsePaymentForm($html)
    {
        $html = $this->populateFormPlaceholder($html, 'SHOPID', $this->shopid);
        $html = $this->populateFormPlaceholder($html, 'AMOUNT', $this->amount);
        $html = $this->populateFormPlaceholder($html, 'ORDERID', $this->orderid);
        $html = $this->populateFormPlaceholder($html, 'CURRENCY', $this->currency);
        $html = $this->populateFormPlaceholder($html, 'PAYTYPE', $this->paytype);
        if( $this->uniqueorderid ) $html = $this->populateFormPlaceholder($html, 'UNIQUEORDERID', $this->uniqueorderid);
        if( $this->orderidprefix ) $html = $this->populateFormPlaceholder($html, 'ORDERIDPREFIX', $this->orderidprefix);
        if( $this->cardtype ) $html = $this->populateFormPlaceholder($html, 'CARDTYPE', $this->cardtype);
        if( $this->authtype ) $html = $this->populateFormPlaceholder($html, 'AUTHTYPE', $this->authtype);
        if( $this->checkmd5 ) $html = $this->populateFormPlaceholder($html, 'CHECKMD5', $this->checkmd5);
        if( $this->accepturl ) $html = $this->populateFormPlaceholder($html, 'ACCEPTURL', $this->accepturl);
        if( $this->declineurl ) $html = $this->populateFormPlaceholder($html, 'DECLINEURL', $this->declineurl);
        if( $this->statusurl ) $html = $this->populateFormPlaceholder($html, 'STATUSURL', $this->statusurl);
        $html = $this->populateFormPlaceholder($html, 'FORMSUBMIT', $this->button_caption);
        return $html;
    }
    
    function getPaymentWindowForm($newWindow = false)
    {
        $html = '<form method="post" action="https://betaling.wannafind.dk/paymentwindow.php" name="formPaymentWindow" id="formPaymentWindow" target="' . ($newWindow ? '_blank' : '_self') . '")>';
        $this->formAddHiddenField('shopid', $this->shopid, &$html);
        $this->formAddHiddenField('currency', $this->currency, &$html);
        $this->formAddHiddenField('amount', $this->amount, &$html);
        $this->formAddHiddenField('orderid', $this->orderid, &$html);
        $this->formAddHiddenField('paytype', $this->paytype, &$html);
        $this->formAddHiddenField('lang', $this->lang, &$html);
        
        $this->formAddHiddenField('accepturl', $this->accepturl, &$html);
        $this->formAddHiddenField('declineurl', $this->declineurl, &$html);
        if( $this->callbackurl ) $this->formAddHiddenField('callbackurl', $this->callbackurl, &$html);
        
        if( $this->uniqueorderid ) $this->formAddHiddenField('uniqueorderid', $this->uniqueorderid, &$html);
        if( $this->orderidprefix ) $this->formAddHiddenField('orderidprefix', $this->orderidprefix, &$html);
        if( $this->cardtype ) $this->formAddHiddenField('cardtype', $this->cardtype, &$html);
        if( $this->authtype ) $this->formAddHiddenField('authtype', $this->authtype, &$html);
        if( $this->checkmd5 ) $this->formAddHiddenField('checkmd5', $this->checkmd5, &$html);
        if( $this->securitytext ) $this->formAddHiddenField('securitytext', $this->securitytext ? 'true' : 'false', &$html);
        
        // add user variables to be transferred to accept/decline page
        foreach( $this->transferredVariables as $var => $value ) $this->formAddHiddenField($var, $value, &$html);
        
        $html .= '</form>';
        return $html;
    }
    
    function getPaymentWindowButton($caption)
    {
        return '<input type="button" value="' . $caption . '" onclick="document.forms[\'formPaymentWindow\'].submit();" />';
    }
    
    function formAddHiddenField($name, $value, $html)
    {
        $html .= '<input type="hidden" name="' . $name . '" value="' . $value . '" />';
    }
    
    function populateFormPlaceholder($html, $tag, $params = array())
    {
        return str_ireplace('%%%' . $tag . '%%%', '%%%' . $tag . '_' . (is_array($params) ? implode('_', $params) : $params) . '%%%', $html);
    }
    
    function _apiExecute($method, $params = array(), $require_login)
    {
        $url = 'https://' . ( $require_login ? $username . ':' . $password . '@' : '' ) . 'betaling.wannafind.dk/api/' . $method;
        $i = 0;
        foreach( $params as $param => $value ) $url .= ( $i++ != 0 ? '&' : '?' ) . $param . '=' . $value;
        return file_get_contents( $url );
    }
    
    function _addApiMethod($method, $remoteMethod, $arguments, $require_login)
    {
        $this->methods[$method] = array(
            'remoteMethod' => $remoteMethod,
            'arguments' => $arguments,
            'require_login' => $require_login
        );
    }
    
    function __call($method, $arguments)
    {
        if( !isset( $this->methods[$method] ) ) return false;
        $data = $this->methods[$method];
        
        $args = array();
        $i = 0;
        foreach( $data['arguments'] as $argument => $argdata )
        {
            if( isset( $this->$argument ) ) $value = $this->$argument;
            else
            {
                ++$i;
                $value = isset( $arguments[$i] ) ? $arguments[$i] : null;
                if( !$value && $argdata['required'] )
                {
                    trigger_error('Missing required argument: ' . $argument);
                    return false;
                }
            }
            $args[$argument] = $value;
        }
        
        return $this->_apiParseResponse(
            $this->_apiExecute(
                $data['remoteMethod'],
                $args,
                $data['require_login']
            )
        );
    }
    
    function apiCheckTransaction($transacknum = null, $shopid = null)
    {
        return $this->__call(
            'apiCheckTransaction', 
            array(
                'transacknum' => $transacknum,
                'shopid' => $shopid
            )
        );
    }
    
    function apiCancelTransaction($transacknum = null, $shopid = null)
    {
        return $this->__call(
            'apiCancelTransaction', 
            array(
                'transacknum' => $transacknum,
                'shopid' => $shopid
            )
        );
    }
    
    function apiCaptureTransaction($transacknum = null, $shopid = null)
    {
        return $this->__call(
            'apiCaptureTransaction', 
            array(
                'transacknum' => $transacknum,
                'shopid' => $shopid
            )
        );
    }
    
    function apiChangeAmount($transacknum = null, $shopid = null, $amount = null)
    {
        return $this->__call(
            'apiChangeAmount', 
            array(
                'transacknum' => $transacknum,
                'shopid' => $shopid,
                'amount' => $amount
            )
        );
    }
    
    function apiRenewTransaction($transacknum = null, $shopid = null)
    {
        return $this->__call(
            'apiRenewTransaction', 
            array(
                'transacknum' => $transacknum,
                'shopid' => $shopid
            )
        );
    }
    
    function _apiParseResponse($responseString)
    {
        $response = array();
        foreach( explode('<BR>', trim( $responseString )) as $line )
        {
            if( ($pos = strpos($line, ':')) === false ) $response[] = $line;
            else
            {
                $response[strtolower( trim( substr($line, 0, $pos) ) )] = substr($line, $pos + 1);
            }
        }
        return $response;
    }
    
    function captureReturnParameters()
    {
        if( isset( $_GET['transacknum'] ) ) $this->transacknum = $_GET['transacknum'];
        if( isset( $_GET['orderid'] ) ) $this->orderid = $_GET['orderid'];
        if( isset( $_GET['amount'] ) ) $this->amount = $_GET['amount'];
        if( isset( $_GET['currency'] ) ) $this->currency = $_GET['currency'];
        if( isset( $_GET['cardtype'] ) ) $this->cardtype = $_GET['cardtype'];
        if( isset( $_GET['actioncode'] ) ) $this->actioncode = $_GET['actioncode'];
        if( isset( $_GET['errorcode'] ) ) $this->errorcode = $_GET['errorcode'];
    }
    
    function returnCheckTransaction()
    {
        $this->captureReturnParameters();
        if( $this->actioncode != 0 ) return false;
        $resp = $this->apiCheckTransaction();
        if( $resp[0] != 'AUTH-APPROVED' ) return false;
        if( $resp['amount'] != $this->amount )
        {
            trigger_error('Wrong amount in transaction check');
            return false;
        }
        return true;
    }
    
    /**
    * add a variable to be transferred to accept/decline page
    * 
    * @param mixed $var
    * @param mixed $value
    */
    function addTransferredVariable($var, $value)
    {
        $this->transferredVariables[$var] = $value;
    }
}
  
?>