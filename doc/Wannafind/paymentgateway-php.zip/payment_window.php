<?php

require 'init.php';
require 'header.php';

?>

<div id="paymentBox">
    <h1>Betaling med kreditkort</h1>
    <p>Online betaling foreg&aring;r i et seperat betalingsvindue for at optimere transaktionens sikkerhed.</p>
    <p>Tryk p&aring; nedenst&aring;ende knap for, at g&aring; til betaling.</p>

    <?php echo $pg->getPaymentWindowForm(); ?>
    <div align="center"><?php echo $pg->getPaymentWindowButton('&Aring;bn betalingvindue'); ?></div>
</div>

<?php require 'footer.php'; ?>