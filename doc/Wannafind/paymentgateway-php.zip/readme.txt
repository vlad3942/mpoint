Wannafind_PaymentGateway PHP class readme

The following describes the two ways to implement Wannafind_PaymentGateway. You should take 
a look at the embedded examples before and after reading this through. The second solution 
is the easier way to implement Wannafind Paymentgateway. It should NOT be neccessary to edit 
the Wannafind_PaymentGateway class. There is no guarantee and support on the implementation 
of this class. It is provided as is and you may use it as you like.


---------------------------------------------------------------------------------------------


1. How-to setup SecureProxy payment with Wannafind_PaymentGateway PHP class:

Create the PHP script file, which should hold the payment form, 
include and initialize the class as done in file init.php. 
Set the following array to suit the the purchase you want to process:

$payment = array(
    'amount' => 1000,
    'orderid' => 1,
    'currency' => 208
);

You could use the payment form used payment_form.php. The content of the payment form is 
passed to $pg->parsePaymentForm() in order to set the fields with the values from the object.
The return value is a string which is printed out to the HTML document.
The form will post directly to the gateway server and the customer will be returned to 
the accepturl or declineurl depending on how the transaction went. In the embedded example,
accepturl and declineurl is the same. We do this because we wont allow users to hit the 
accept url instead of the decline url - all users go to the same url, where we do a 
transaction check against the Paymentgateway API.

The accept/decline file should initialize the Wannafind_PaymentGateway PHP class as on the 
previous page. Then the returnCheckTransaction() method should be called on the object.
This method imports the variables from the querystring and checks the transaction if 
actioncode is zero (this is what the payment gateway returns if everything is ok).
The method always returns a boolean value (true or false). If true then the transaction is 
approved, if false then the transaction was declined by the gateway.


---------------------------------------------------------------------------------------------


2. How-to setup PaymentWindow solution with Wannafind_PaymentGateway PHP class:

On the page where you want the payment window to be opened from, you should instantiate 
and initialize the class the same way as in the above example. But instead of generating a 
nice form with placeholders, you should call and print out the return value from this 
method: getPaymentWindowForm() on the Wannafind_PaymentGateway object. The output is a 
HTML form with some hidden fields.

All you need to do now is print out the return value from the 
getPaymentWindowButton($caption) method called on the Wannafind_PaymentGateway object.
The $caption argument should be replaced by the string which should be displayed on the 
button. When a user clicks the button, the browser is redirected to the payment window.

The accept/decline file should initialize the Wannafind_PaymentGateway PHP class as on the 
previous page. Then the returnCheckTransaction() method should be called on the object.
This method imports the variables from the querystring and checks the transaction if 
actioncode is zero (this is what the payment gateway returns if everything is ok).
The method always returns a boolean value (true or false). If true then the transaction is 
approved, if false then the transaction was declined by the gateway.
