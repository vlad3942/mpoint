<?php

require 'init.php';
require 'header.php';

?>

<div id="paymentBox">
    <?php
    if( $pg->returnCheckTransaction() )
    {
        ?>
        <h1>Betaling gennemf�rt</h1>
        <table>
            <tr>
                <td><strong>Ordre nr.</strong></td>
                <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
                <td><?php echo $pg->orderid; ?></td>
            </tr>
            <tr>
                <td><strong>Bel&oslash;b</strong></td>
                <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
                <td>DKK <?php echo number_format($pg->amount, 2, ',', '.'); ?></td>
            </tr>
            <tr>
                <td><strong>Transaktionsnummer</strong></td>
                <td>&nbsp;&nbsp;:&nbsp;&nbsp;</td>
                <td><?php echo $pg->transacknum; ?></td>
            </tr>
        </table>
        <?php
    }
    else
    {
        echo '<h1>Betaling fejlede</h1>';
        echo '<p>Dit k�b blev afvist. Pr�v igen.</p>
    <p><a href="' . HTTPS_LOCATION . 'payment_form.php">Tilbage til SecureProxy l�sning</a></p>
    <p><a href="payment_window.php">Tilbage til Betalingsvindue l�sning</a></p>';
    }
    ?>
</div>
<?php require 'footer.php'; ?>