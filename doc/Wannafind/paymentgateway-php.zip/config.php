<?php

/** CONFIG **/
define('DOMAIN', '');
define('WANNAFIND_PAYMENTGATEWAY_PROXY_LOCATION', 'https://betaling.wannafind.dk/secureproxy/proxy.php/');
define('WANNAFIND_PAYMENTGATEWAY_SHOPID', '');
define('WANNAFIND_PAYMENTGATEWAY_USERNAME', '');
define('WANNAFIND_PAYMENTGATEWAY_PASSWORD', '');
define('HTTP_ROOT_PATH', '/');

?>
