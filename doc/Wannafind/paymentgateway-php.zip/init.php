<?php


/** INCLUDE CONFIG FILE **/
require 'config.php';


/** CONSTANTS **/
define('HTTP_LOCATION', 'http://' . DOMAIN . HTTP_ROOT_PATH);
define('HTTPS_LOCATION', WANNAFIND_PAYMENTGATEWAY_PROXY_LOCATION . HTTP_LOCATION);


/** INCLUDE PHP4 COMPATIBILITY LIBRARY **/
if( phpversion() < 5 ) require 'php4_compat_lib.php';


/** INCLUDE CLASS **/
require phpversion() > 5 ? 'Wannafind_PaymentGateway.php' : 'Wannafind_PaymentGateway-php4.php';


/** LOAD SESSION **/
session_start();


/** INITIALIZE CLASS **/
$pg = new Wannafind_PaymentGateway;
$pg->username = WANNAFIND_PAYMENTGATEWAY_USERNAME;
$pg->password = WANNAFIND_PAYMENTGATEWAY_PASSWORD;
$pg->shopid = WANNAFIND_PAYMENTGATEWAY_SHOPID;
$pg->accepturl = HTTP_LOCATION . 'payment_return.php';
$pg->declineurl = HTTP_LOCATION . 'payment_return.php';
$pg->button_caption = 'Betal';
$pg->lang = 'da';
$pg->securitytext = true;


/** SET PAYMENT INFO FROM SESSIONS VARS **/
if( isset( $_SESSION['payment'] ) )
{
    $pg->amount = $_SESSION['payment']['amount'];
    $pg->orderid = $_SESSION['payment']['orderid'];
    $pg->currency = $_SESSION['payment']['currency'];
}


/*
* The purchase data is set in index.php
*    (amount, currency and orderid)
*/

?>
